<section class="cta">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h2 class="heading text-center mb10 wow wow2 fadeInUp" data-wow-delay="200ms">Still have questions?
                    <hr>
                </h2>
                <a href="contact.php" class="btn btn-primary-bordered wow wow2 fadeInUp" data-wow-delay="300ms">Contact us<span>></span></a>
            </div>
        </div>
    </div>
</section>