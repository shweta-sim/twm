<h2 class="heading text-center mb40 wow fadeInUp" data-wow-delay="200ms">What do you need designed?
    <hr>
</h2>

<!-- start tabs -->

<ul class="nav nav-pills wow fadeInUp" data-wow-delay="300ms" id="pills-tab" role="tablist">
    <li class="nav-item"> <a class="nav-link logos" id="pills-logos-tab" href="our-work-logos.php">Logos</a> </li>
    <li class="nav-item"> <a class="nav-link branding" id="pills-branding-tab" href="our-work-branding.php">Branding</a> </li>
    <li class="nav-item"> <a class="nav-link socialmedia" id="pills-socialmedia-tab" href="our-work-social-media.php">Social Media</a> </li>
    <li class="nav-item"> <a class="nav-link flyersposters" id="pills-flyersposters-tab" href="our-work-flyers-posters.php">Leaflets &amp; Posters</a> </li>
    <li class="nav-item"> <a class="nav-link websitesapps" id="pills-websitesapps-tab" href="our-work-websites-apps.php">Websites &amp; Apps</a> </li>
    <li class="nav-item"> <a class="nav-link prototypessketches" id="pills-prototypessketches-tab" href="our-work-prototypes-sketches.php">Prototypes &amp; Sketches</a> </li>
    <li class="nav-item"> <a class="nav-link researchdiscovery" id="pills-researchdiscovery-tab" href="our-work-design-sprints.php">Design Sprints &amp; Discovery</a> </li>
    <li class="nav-item"> <a class="nav-link photography" id="pills-photography-tab" href="our-work-photography.php">Photography</a> </li>
    <li class="nav-item"> <a class="nav-link videos" id="pills-videos-tab" href="our-work-videos.php">Videos</a> </li>
    <li class="nav-item"> <a class="nav-link businesscards" id="pills-businesscards-tab" href="our-work-business-cards.php">Business Cards</a> </li>
    <li class="nav-item"> <a class="nav-link pitchdecks" id="pills-pitchdecks-tab" href="our-work-pitch-decks.php">Pitch Decks</a> </li>
</ul>